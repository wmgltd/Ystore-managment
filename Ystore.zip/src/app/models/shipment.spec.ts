import { Shipment } from './shipment';

describe('Shipment', () => {
  it('should create an instance', () => {
    expect(new Shipment()).toBeTruthy();
  });
});
