export class Shipment {
    id : number;
    store_id : number;
    name : string;
    sum : number;
    condition : string;
    status : number;
}
