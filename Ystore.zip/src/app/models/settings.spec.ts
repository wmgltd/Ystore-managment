import { Settings } from './settings';

describe('Settings', () => {
  it('should create an instance', () => {
    expect(new Settings()).toBeTruthy();
  });
});
