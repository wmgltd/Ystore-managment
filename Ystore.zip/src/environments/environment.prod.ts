export const environment = {
  production: true,
  baseUrl: '../Ystore-server/api/'
};
